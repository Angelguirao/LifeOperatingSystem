# LifeOS Deployment Guide

This guide will help you deploy LifeOS to AWS using serverless architecture.

## 🚀 **Prerequisites**

1. **AWS Account** with appropriate permissions
2. **AWS CLI** installed and configured
3. **Node.js** (v18 or later)
4. **Serverless Framework** (will be installed via npm)

## 📦 **Installation**

```bash
# Install dependencies
npm install

# Install Serverless Framework globally (optional)
npm install -g serverless
```

## 🔧 **Configuration**

### 1. Environment Variables

Create a `.env` file in the root directory:

```env
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/lifeos
AWS_REGION=us-east-1
```

### 2. AWS Credentials

Make sure your AWS credentials are configured:

```bash
aws configure
```

## 🧪 **Local Testing**

### Test Serverless Functions Locally

```bash
# Start serverless offline
npm run serverless:dev
```

This will start the serverless functions locally on `http://localhost:3001`

### Test the Frontend

Open `frontend/index.html` in your browser and configure the API URL to point to your local serverless instance.

## ☁️ **AWS Deployment**

### 1. Deploy Backend

```bash
# Deploy to AWS
npm run serverless:deploy
```

This will:
- Create Lambda functions for each API endpoint
- Set up API Gateway
- Configure CORS
- Set environment variables

### 2. Get Your API Gateway URL

After deployment, you'll see output like:

```
endpoints:
  GET - https://abc123.execute-api.us-east-1.amazonaws.com/dev/api/events
  POST - https://abc123.execute-api.us-east-1.amazonaws.com/dev/api/events
  GET - https://abc123.execute-api.us-east-1.amazonaws.com/dev/api/events/{id}
  DELETE - https://abc123.execute-api.us-east-1.amazonaws.com/dev/api/events/{id}
  GET - https://abc123.execute-api.us-east-1.amazonaws.com/dev/api/health
```

**Note down the base URL**: `https://abc123.execute-api.us-east-1.amazonaws.com/dev`

### 3. Deploy Frontend

#### Option A: Deploy to S3 + CloudFront

```bash
# Create S3 bucket (replace with your bucket name)
aws s3 mb s3://lifeos-frontend

# Upload frontend files
aws s3 sync frontend/ s3://lifeos-frontend --delete

# Enable static website hosting
aws s3 website s3://lifeos-frontend --index-document index.html
```

#### Option B: Deploy to Vercel/Netlify

1. Push your code to GitHub
2. Connect your repository to Vercel or Netlify
3. Deploy automatically

### 4. Update Frontend Configuration

Update the API URL in `frontend/index.html` or configure it through the web interface to point to your AWS API Gateway URL.

## 🔄 **CI/CD with GitHub Actions**

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy LifeOS

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        
    - name: Install dependencies
      run: npm install
      
    - name: Configure AWS credentials
      uses: aws-actions/configure-aws-credentials@v1
      with:
        aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: us-east-1
        
    - name: Deploy to AWS
      run: npm run serverless:deploy
      env:
        MONGODB_URI: ${{ secrets.MONGODB_URI }}
```

## 🧹 **Cleanup**

To remove all AWS resources:

```bash
npm run serverless:remove
```

## 🔍 **Monitoring**

### CloudWatch Logs

View Lambda function logs:

```bash
# Get logs for a specific function
aws logs tail /aws/lambda/lifeos-backend-dev-getEvents --follow

# Get logs for all functions
aws logs tail /aws/lambda/lifeos-backend-dev --follow
```

### API Gateway Monitoring

Monitor API usage in the AWS Console:
- API Gateway → Your API → Stages → dev → Monitoring

## 🚨 **Troubleshooting**

### Common Issues

1. **CORS Errors**: Make sure CORS is enabled in `serverless.yml`
2. **MongoDB Connection**: Verify your MongoDB Atlas connection string
3. **Lambda Timeout**: Increase timeout in `serverless.yml` if needed
4. **Cold Starts**: Consider using provisioned concurrency for better performance

### Debug Commands

```bash
# Check serverless configuration
serverless print

# Validate serverless.yml
serverless validate

# Check AWS resources
aws cloudformation describe-stacks --stack-name lifeos-backend-dev
```

## 📈 **Next Steps**

After successful deployment:

1. **Add Authentication** using AWS Cognito
2. **Set up CloudWatch Alarms** for monitoring
3. **Configure Custom Domain** for API Gateway
4. **Add CDN** for frontend assets
5. **Implement Backup Strategy** for MongoDB

## 🔐 **Security Considerations**

- Use AWS Secrets Manager for sensitive environment variables
- Enable AWS WAF for API Gateway
- Configure proper IAM roles and policies
- Enable CloudTrail for audit logging
- Use VPC for Lambda functions if needed 